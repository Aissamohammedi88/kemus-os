# Kemus — PC virtuel leger

> Inspire **KDE Plasma** + **NixOS** + **Fedora**, execute dans le navigateur,
> zero dependance Python externe. Un seul fichier, ~1500 lignes, port **3922**.

## Qu'est-ce que c'est ?

Kemus est un **vrai PC virtuel** dans le navigateur : un bureau complet avec
fenetres drag & drop, taskbar, menu Kickoff (icone flocon NixOS), un terminal
**reel** connecte a un VFS persistant sur disque (`~/.kemus/home/`), un
gestionnaire de fichiers, un editeur de texte, une calculatrice, un navigateur
simule et un panneau de parametres.

Tout le backend tient dans **`kemus.py`** (Python 3.8+, stdlib uniquement).
Aucun pip requis. Aucun node, aucun webpack, aucune image externe.

## Installation (1 commande)

```bash
bash install.sh           # auto : system si possible, sinon --user
# ou
bash install.sh --user    # force user
bash install.sh --dev     # editable (developpement)
```

Apres :

```bash
kemus                     # demarre sur http://localhost:3922
```

## Installation alternative : pip direct

```bash
pip install .             # depuis le dossier kemus/
kemus
```

Ou sans installer :

```bash
python3 kemus.py          # http://localhost:3922
KEMUS_PORT=4000 python3 kemus.py   # port custom
```

## Fonctionnalites

| Module           | Description                                                 |
|------------------|-------------------------------------------------------------|
| **Bureau**       | Gradient NixOS + wallpaper SVG flocon, panels KDE           |
| **Kickoff**      | Menu applications avec recherche, comme KDE Plasma          |
| **Dock**         | Barre d'icônes inferieure style Plasma                      |
| **Fenetres**     | Drag & drop, redimension, minimize/maximize/close, focus z   |
| **Terminal**     | Vrai shell : `ls cd cat mkdir touch rm mv cp find tree echo` |
|                  | `pwd date whoami uname neofetch ps top df free history`     |
|                  | `python -c "..."` (executé dans le sandbox VFS)             |
|                  | `apt/dnf/pacman/nix install|remove|search|list` (simulés)   |
|                  | `edit <file>` ouvre l'editeur ; `clear`, `exit`             |
| **Fichiers**     | Gestionnaire type Dolphin : sidebar + grille + mkdir/touch   |
| **Editeur**      | Type Kate : load/save via API `/api/file/save`               |
| **Calculatrice** | Type kcalc : eval safe (regex)                               |
| **Navigateur**   | Simule (iframe sandbox)                                      |
| **Parametres**   | Info systeme KemusOS                                         |
| **Aide**         | Raccourcis et commandes                                      |
| **Boot screen**  | Sequence de demarrage avec progress bar                      |
| **Toasts**       | Notifications type Plasma                                    |

## VFS reel (le vrai PC)

Tous les fichiers que vous créez dans le terminal (`touch`, `mkdir`, `echo >`,
`edit`) sont **persistants sur disque** :

```
~/.kemus/
├── home/           <- VFS racine (cd ~ ici)
│   ├── README.txt
│   ├── hello.py
│   ├── Documents/
│   ├── Projects/
│   └── ...
├── kemus.log       <- logs du serveur
```

Vous pouvez `cat`, `edit`, `python hello.py` depuis le terminal — les fichiers
existent vraiment.

## API HTTP

| Endpoint                  | Methode | Description                       |
|---------------------------|---------|-----------------------------------|
| `/`                       | GET     | Page HTML du bureau               |
| `/api/health`             | GET     | `{ok, version, uptime}`           |
| `/api/desktop`            | GET     | Info distribution                 |
| `/api/fs?path=`           | GET     | Liste un dossier                  |
| `/api/file?path=`         | GET     | Lit un fichier                    |
| `/api/file/save`          | POST    | Sauvegarde `{path, content}`      |
| `/api/terminal`           | POST    | Execute `{cmd, cwd}` -> `{output, cwd, session, prompt}` |

## Sessions

Chaque onglet a une session (`kemus_session` cookie), donc le `cwd` du
terminal et l'historique sont persistants entre les requetes.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Navigateur (Firefox/Chrome)                             │
│   HTML/CSS/JS embarque dans kemus.py                     │
│   Window manager + Terminal client + Apps                │
└────────────────────────┬────────────────────────────────┘
                         │ HTTP localhost:3922
                         │  (fetch POST /api/*)
┌────────────────────────▼────────────────────────────────┐
│  Python kemus.py (ThreadingHTTPServer, stdlib only)      │
│   - run_command(cmd, cwd) -> 30+ commandes               │
│   - VFS reel via pathlib, sandboxe sous VFS_ROOT          │
│   - Sessions en memoire (cwd + history)                  │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
                  ~/.kemus/home/   (disque reel, persistant)
```

## Limitations

- Pas de reseau sortant dans le terminal (sandbox volontaire)
- `python -c` s'execute en subprocess 10s max (timeout)
- 1 session = 1 onglet ; pas de partage multi-onglet
- Le VFS est sandboxe : `cd /etc` echoue volontairement

## Roadmap

- WebSocket pour output streaming (longues commandes)
- Multi-utilisateurs
- Theme Breeze clair
- Paquet `kemus-themes` separable

## Licence

MIT.
